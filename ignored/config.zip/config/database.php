<?php

// MySQL Database Details
define('DB_HOST',      'localhost');
define('DB_USERNAME',  'root');
define('DB_PASSWORD',  'Root@123');
define('DB_NAME',      'keysmat');
define('DB_PREFIX',    '');
