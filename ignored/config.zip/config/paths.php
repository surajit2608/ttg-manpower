<?php

define('BASE_DIR',    realpath(__DIR__ . '/../'));
define('LOGS_DIR',    BASE_DIR . '/public/storage/logs');
define('STORAGE_DIR', BASE_DIR . '/public/storage');
define('APP_DIR',     BASE_DIR . '/apps');
define('UPLOAD_DIR',  BASE_DIR . '/public/uploads');
