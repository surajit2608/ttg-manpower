<?php

// Email Constant
define('SMTP_SECURE',    'ssl');
define('SMTP_HOST',      'smtp.gmail.com');
define('SMTP_PORT',      '465');
define('SMTP_USERNAME',  'dev.surajit.dev@gmail.com');
define('SMTP_PASSWORD',  'rdzoyqtjntenschd');
define('SMTP_FROMEMAIL', 'info@keysmat.com');
define('SMTP_FROMNAME',  'Keysmat Property Managment');

// Set this to your email id
define('DEVELOPER_EMAIL', 'jitdxpert@gmail.com');
