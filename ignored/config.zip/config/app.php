<?php

// Main Config
define('DEBUG',       true);

define('BASE_URL',    '');
define('SITE_TITLE',  'Keysmat Property Managment');

$url = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'];

define('SITE_URL',    BASE_URL);
define('FULL_URL',    $url . BASE_URL);

define('DEV_URL',     BASE_URL . '/-dev');
define('ADMIN_URL',   BASE_URL . '/admin');
define('UPLOAD_URL',  BASE_URL . '/uploads');

define('HASH_KEY',    'kstho41#41lyusk5@87k');
