<?php

// Google API ID & Secret Key
define('GOOGLE_API_KEY', 'AIzaSyD5YsNtNs0I6EQBNyXzEzVQ8nH90t4iEyo');

